// src/App.js
import React, { useEffect, useState } from "react";
import { supabase } from "./supabaseClient";
import Login from "./components/Login";
import Dashboard from "./components/Dashboard";

function App() {
  const [session, setSession] = useState(null);

  useEffect(() => {
    // Captura la sesión actual
    supabase.auth.getSession().then(({ data }) => setSession(data.session));

    // Escucha cambios en la sesión
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => {
      listener.subscription.unsubscribe();
    };
  }, []);

  return <div>{session ? <Dashboard session={session} /> : <Login />}</div>;
}

export default App;
