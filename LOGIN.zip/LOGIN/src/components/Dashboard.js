// src/components/Dashboard.js
import React from "react";
import { supabase } from "../supabaseClient";

const Dashboard = ({ session }) => {
  return (
<div className="dashboard">
  <h1>¡Bienvenido!</h1>
  <p>Email: {session.user.email}</p>
  <button onClick={() => supabase.auth.signOut()}>Cerrar sesión</button>
</div>

  );
};

export default Dashboard;
