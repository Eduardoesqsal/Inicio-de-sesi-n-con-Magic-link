// src/components/Login.js
import React, { useState } from "react";
import { supabase } from "../supabaseClient";

const Login = () => {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");

  const handleLogin = async (e) => {
    e.preventDefault();

    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: { emailRedirectTo: "http://localhost:3000" }
    });

    if (error) setMessage(`Error: ${error.message}`);
    else setMessage("Revisa tu correo, te enviamos un Magic Link!");
  };

  return (
    <div className="container">
  <h2>Login con Magic Link</h2>
  <form onSubmit={handleLogin}>
    <input
      type="email"
      placeholder="Tu correo"
      value={email}
      onChange={(e) => setEmail(e.target.value)}
      required
    />
    <button type="submit">Enviar Magic Link</button>
  </form>
  {message && <p className="message">{message}</p>}
</div>

  );
};

export default Login;
