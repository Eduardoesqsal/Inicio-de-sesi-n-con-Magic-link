// src/supabaseClient.js
import { createClient } from "@supabase/supabase-js";

const supabaseUrl = ""; // reemplaza con tu URL
const supabaseAnonKey = ""; // reemplaza con tu anon key

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
